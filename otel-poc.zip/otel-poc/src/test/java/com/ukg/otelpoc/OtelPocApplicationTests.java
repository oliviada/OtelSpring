package com.ukg.otelpoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtelPocApplicationTests {

    @Test
    void contextLoads() {
    }

}
