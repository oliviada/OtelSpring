package com.ukg.otelpoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtelPocApplication {

    public static void main(String[] args) {
        SpringApplication.run(OtelPocApplication.class, args);
    }

}
